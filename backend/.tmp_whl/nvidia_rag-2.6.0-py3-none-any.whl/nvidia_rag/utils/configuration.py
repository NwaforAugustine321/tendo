# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Simple configuration for NVIDIA RAG."""

import json
import logging
import os
from enum import StrEnum
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import yaml
from pydantic import BaseModel, ConfigDict, SecretStr, field_validator, model_validator
from pydantic import Field as PydanticField
from pydantic.fields import FieldInfo

logger = logging.getLogger(__name__)


def Field(default=None, *, env: str = None, description: str = None, **kwargs):
    """Pydantic Field with optional environment variable support.

    Args:
        default: Default value
        env: Environment variable name (optional)
        description: Description of what the field is for (optional)
        **kwargs: Other Pydantic Field parameters

    Example:
        name: str = Field(default="elasticsearch", env="APP_VECTORSTORE_NAME", description="Vector store name")
    """
    if env:
        if "json_schema_extra" not in kwargs:
            kwargs["json_schema_extra"] = {}
        kwargs["json_schema_extra"]["env"] = env

    if description:
        kwargs["description"] = description

    return PydanticField(default=default, **kwargs)


class _ConfigBase(BaseModel):
    """Base configuration class with automatic environment variable loading.

    Usage:
        class MyConfig(_ConfigBase):
            server_url: str = Field(default="", env="MY_SERVER_URL")

    Priority: dict/yaml values > env vars > defaults
    """

    def __init__(self, **data):
        # Load values from environment variables
        env_values = {}
        for field_name, field_info in self.model_fields.items():
            # Check if Field has 'env' in json_schema_extra
            if isinstance(field_info, FieldInfo) and field_info.json_schema_extra:
                env_var_name = field_info.json_schema_extra.get("env")
                if env_var_name and env_var_name in os.environ:
                    raw_value = os.environ[env_var_name]
                    # Strip surrounding quotes if present (handles Docker Compose quoted values)
                    if isinstance(raw_value, str) and len(raw_value) >= 2:
                        # More robust quote stripping: strip whitespace first, then quotes
                        raw_value = raw_value.strip()
                        if (raw_value.startswith('"') and raw_value.endswith('"')) or (
                            raw_value.startswith("'") and raw_value.endswith("'")
                        ):
                            raw_value = raw_value[1:-1]
                    env_values[field_name] = raw_value

        # Merge: data overrides env vars, env vars override defaults
        merged_data = {**env_values, **data}

        super().__init__(**merged_data)

    def get_api_key(self) -> str | None:
        """Get API key with fallback to global NVIDIA_API_KEY or NGC_API_KEY.

        Returns:
            API key string if found, None otherwise.
        """
        if hasattr(self, "api_key") and self.api_key:
            api_key_value = self.api_key.get_secret_value()
            if api_key_value:
                return api_key_value

        return os.environ.get("NVIDIA_API_KEY") or os.environ.get("NGC_API_KEY")


class SearchType(StrEnum):
    """Allowed search types for vector store queries."""

    DENSE = "dense"
    HYBRID = "hybrid"


class RankerType(StrEnum):
    """Allowed ranker types for vector store in case of Hybrid Search"""

    RRF = "rrf"
    WEIGHTED = "weighted"


class VectorStoreConfig(_ConfigBase):
    """Vector Store configuration.

    Environment variables:
        APP_VECTORSTORE_NAME, APP_VECTORSTORE_URL, APP_VECTORSTORE_INDEXTYPE,
        APP_VECTORSTORE_SEARCHTYPE, COLLECTION_NAME, etc.
    """

    name: str = Field(
        default="elasticsearch",
        env="APP_VECTORSTORE_NAME",
        description="Name of the vector store backend (e.g., milvus, elasticsearch, lancedb)",
    )
    url: str = Field(
        default="http://localhost:9200",
        env="APP_VECTORSTORE_URL",
        description="URL endpoint for the vector store service (or LanceDB directory path)",
    )

    @field_validator("name", "url", mode="before")
    @classmethod
    def normalize_string(cls, v: Any) -> Any:
        """Normalize string fields by stripping whitespace and quotes."""
        if isinstance(v, str):
            return v.strip().strip('"').strip("'")
        return v

    nlist: int = Field(
        default=64,
        env="APP_VECTORSTORE_NLIST",
        description="Number of clusters for IVF index",
    )
    nprobe: int = Field(
        default=16,
        env="APP_VECTORSTORE_NPROBE",
        description="Number of clusters to search during query",
    )
    index_type: str = Field(
        default="GPU_CAGRA",
        env="APP_VECTORSTORE_INDEXTYPE",
        description="Type of vector index (e.g., GPU_CAGRA, IVF_FLAT)",
    )
    enable_gpu_index: bool = Field(
        default=False,
        env="APP_VECTORSTORE_ENABLEGPUINDEX",
        description="Enable GPU acceleration for index building (Milvus and Elasticsearch)",
    )
    enable_gpu_search: bool = Field(
        default=False,
        env="APP_VECTORSTORE_ENABLEGPUSEARCH",
        description="Enable GPU acceleration for search operations (Milvus only; not supported by Elasticsearch)",
    )
    search_type: SearchType = Field(
        default=SearchType.DENSE,
        env="APP_VECTORSTORE_SEARCHTYPE",
        description="Type of search to perform (dense, hybrid)",
    )
    ranker_type: RankerType = Field(
        default=RankerType.RRF,
        env="APP_VECTORSTORE_RANKER_TYPE",
        description="Type of ranker to use ('rrf', 'weighted')",
    )
    dense_weight: float = Field(
        default=0.5,
        env="APP_VECTORSTORE_DENSE_WEIGHT",
        description="Weight for dense vector search in case of weighted Hybrid Search",
    )
    sparse_weight: float = Field(
        default=0.5,
        env="APP_VECTORSTORE_SPARSE_WEIGHT",
        description="Weight for sparse vector search in case of weighted Hybrid Search",
    )
    default_collection_name: str = Field(
        default="multimodal_data",
        env="COLLECTION_NAME",
        description="Default collection/index name for storing vectors",
    )
    ef: int = Field(
        default=100,
        env="APP_VECTORSTORE_EF",
        description="Size of the dynamic candidate list for HNSW search",
    )
    username: str = Field(
        default="",
        env="APP_VECTORSTORE_USERNAME",
        description="Username for vector store authentication",
    )
    password: SecretStr | None = Field(
        default=None,
        env="APP_VECTORSTORE_PASSWORD",
        description="Password for vector store authentication",
    )

    # API key authentication for vector store (used by Elasticsearch)
    api_key: SecretStr | None = Field(
        default=None,
        env="APP_VECTORSTORE_APIKEY",
        description="API key for vector store authentication (base64 form 'id:secret')",
    )
    api_key_id: str = Field(
        default="",
        env="APP_VECTORSTORE_APIKEY_ID",
        description="API key ID for vector store authentication",
    )
    api_key_secret: SecretStr | None = Field(
        default=None,
        env="APP_VECTORSTORE_APIKEY_SECRET",
        description="API key secret for vector store authentication",
    )

    @model_validator(mode="after")
    def default_lancedb_uri(self) -> "VectorStoreConfig":
        """Point LanceDB at the ingestor-mounted data dir when URL was left at ES default.

        In Docker Compose, ``./volumes/lancedb`` is mounted at ``/volumes/lancedb``;
        the database directory defaults to ``/volumes/lancedb/lancedb``.  If
        ``APP_VECTORSTORE_URL`` is set explicitly, it is respected.
        """
        if self.name.lower() != "lancedb":
            return self
        default_es_url = "http://localhost:9200"
        if not self.url or self.url == default_es_url:
            self.url = "/volumes/lancedb/lancedb"
        return self


class NvIngestConfig(_ConfigBase):
    """NV-Ingest configuration."""

    message_client_hostname: str = Field(
        default="localhost",
        env="APP_NVINGEST_MESSAGECLIENTHOSTNAME",
        description="Hostname for NV-Ingest message client",
    )
    message_client_port: int = Field(
        default=7670,
        env="APP_NVINGEST_MESSAGECLIENTPORT",
        description="Port for NV-Ingest message client",
    )

    @field_validator("message_client_port")
    @classmethod
    def validate_port(cls, v: int) -> int:
        if not (1 <= v <= 65535):
            raise ValueError("Port must be between 1 and 65535")
        return v

    extract_text: bool = Field(
        default=True,
        env="APP_NVINGEST_EXTRACTTEXT",
        description="Enable text extraction from documents",
    )
    extract_infographics: bool = Field(
        default=False,
        env="APP_NVINGEST_EXTRACTINFOGRAPHICS",
        description="Enable infographic extraction from documents",
    )
    extract_tables: bool = Field(
        default=True,
        env="APP_NVINGEST_EXTRACTTABLES",
        description="Enable table extraction from documents",
    )
    extract_charts: bool = Field(
        default=True,
        env="APP_NVINGEST_EXTRACTCHARTS",
        description="Enable chart extraction from documents",
    )
    extract_images: bool = Field(
        default=False,
        env="APP_NVINGEST_EXTRACTIMAGES",
        description="Enable image extraction from documents",
    )
    extract_page_as_image: bool = Field(
        default=False,
        env="APP_NVINGEST_EXTRACTPAGEASIMAGE",
        description="Extract entire pages as images",
    )
    structured_elements_modality: str = Field(
        default="",
        env="STRUCTURED_ELEMENTS_MODALITY",
        description="Modality for processing structured elements (tables, charts)",
    )
    image_elements_modality: str = Field(
        default="",
        env="IMAGE_ELEMENTS_MODALITY",
        description="Modality for processing image elements",
    )
    pdf_extract_method: str | None = Field(
        default=None,
        env="APP_NVINGEST_PDFEXTRACTMETHOD",
        description="Method to use for PDF extraction",
    )

    @field_validator("pdf_extract_method", mode="before")
    @classmethod
    def normalize_pdf_extract_method(cls, v: Any) -> Any:
        """Normalize string 'None'/'none' to Python None."""
        if isinstance(v, str) and v.lower() in ("none", "null", ""):
            return None
        return v

    text_depth: str = Field(
        default="page",
        env="APP_NVINGEST_TEXTDEPTH",
        description="Granularity level for text extraction (page, document)",
    )
    extract_tables_method: str | None = Field(
        default=None,
        env="APP_NVINGEST_EXTRACTTABLESMETHOD",
        description="Method for table/chart extraction in PDFs (e.g. yolox, nemotron_parse). If None, client default is used.",
    )

    @field_validator("extract_tables_method", mode="before")
    @classmethod
    def normalize_extract_tables_method(cls, v: Any) -> Any:
        """Normalize string 'None'/'none' to Python None."""
        if isinstance(v, str) and v.lower() in ("none", "null", ""):
            return None
        return v

    page_elements_invoke_url: str | None = Field(
        default="https://ai.api.nvidia.com/v1/cv/nvidia/nemotron-page-elements-v3",
        env="APP_NVINGEST_PAGEELEMENTSURL",
        description="Invoke URL for the page-elements NIM (e.g. https://ai.api.nvidia.com/v1/cv/nvidia/nemotron-page-elements-v3)",
    )

    graphic_elements_invoke_url: str | None = Field(
        default="https://ai.api.nvidia.com/v1/cv/nvidia/nemotron-graphic-elements-v1",
        env="APP_NVINGEST_GRAPHICELEMENTSURL",
        description="Invoke URL for the graphic-elements NIM (e.g. https://ai.api.nvidia.com/v1/cv/nvidia/nemotron-graphic-elements-v1)",
    )

    ocr_invoke_url: str | None = Field(
        default="https://ai.api.nvidia.com/v1/cv/nvidia/nemotron-ocr-v1",
        env="APP_NVINGEST_OCRURL",
        description="Invoke URL for the OCR NIM (e.g. https://ai.api.nvidia.com/v1/cv/nvidia/nemotron-ocr-v1)",
    )

    table_structure_invoke_url: str | None = Field(
        default="https://ai.api.nvidia.com/v1/cv/nvidia/nemotron-table-structure-v1",
        env="APP_NVINGEST_TABLESTRUCTUREURL",
        description="Invoke URL for the table-structure NIM (e.g. https://ai.api.nvidia.com/v1/cv/nvidia/nemotron-table-structure-v1)",
    )

    tokenizer: str = Field(
        default="intfloat/e5-large-unsupervised",
        env="APP_NVINGEST_TOKENIZER",
        description="Tokenizer model for text chunking",
    )
    chunk_size: int = Field(
        default=1024,
        env="APP_NVINGEST_CHUNKSIZE",
        description="Maximum size of text chunks in tokens",
    )
    chunk_overlap: int = Field(
        default=150,
        env="APP_NVINGEST_CHUNKOVERLAP",
        description="Number of overlapping tokens between chunks",
    )
    caption_model_name: str = Field(
        default="nvidia/nemotron-3-nano-omni-30b-a3b-reasoning",
        env="APP_NVINGEST_CAPTIONMODELNAME",
        description="Model name for generating image captions",
    )
    caption_endpoint_url: str = Field(
        default="https://integrate.api.nvidia.com/v1/chat/completions",
        env="APP_NVINGEST_CAPTIONENDPOINTURL",
        description="API endpoint for caption generation service",
    )

    @field_validator("caption_endpoint_url", mode="before")
    @classmethod
    def normalize_url(cls, v: Any) -> Any:
        """Normalize URL fields by stripping whitespace/quotes and adding scheme."""
        if isinstance(v, str):
            v = v.strip().strip('"').strip("'")
            if v and not v.startswith(("http://", "https://")):
                return f"http://{v}"
        return v

    @model_validator(mode="after")
    def validate_chunk_settings(self) -> "NvIngestConfig":
        if self.chunk_overlap > self.chunk_size:
            raise ValueError(
                f"chunk_overlap ({self.chunk_overlap}) must be less than chunk_size ({self.chunk_size})"
            )
        return self

    enable_paged_doc_split: bool = Field(
        default=False,
        env="APP_NVINGEST_ENABLE_PAGED_DOC_SPLIT",
        description="Enable splitting for paged documents (PDF/DOCX/PPTX) during ingestion",
    )
    segment_audio: bool = Field(
        default=False,
        env="APP_NVINGEST_SEGMENTAUDIO",
        description="Enable audio segmentation during ingestion",
    )
    save_to_disk: bool = Field(
        default=False,
        env="APP_NVINGEST_SAVETODISK",
        description="Save extracted content to disk for debugging",
    )
    object_store_bucket: str = Field(
        default="nv-ingest",
        env="NVINGEST_OBJECTSTORE_BUCKET",
        description="Object-store bucket used by NV-Ingest and Milvus integrations",
    )
    # Batch processing configuration
    enable_batch_mode: bool = Field(
        default=True,
        env="ENABLE_NV_INGEST_BATCH_MODE",
        description="Process files in batches for better throughput",
    )
    files_per_batch: int = Field(
        default=16,
        env="NV_INGEST_FILES_PER_BATCH",
        description="Number of files to process in each batch",
    )
    enable_parallel_batch_mode: bool = Field(
        default=True,
        env="ENABLE_NV_INGEST_PARALLEL_BATCH_MODE",
        description="Enable parallel processing of multiple batches",
    )
    concurrent_batches: int = Field(
        default=4,
        env="NV_INGEST_CONCURRENT_BATCHES",
        description="Number of batches to process concurrently",
    )
    enable_dynamic_batching: bool = Field(
        default=False,
        env="ENABLE_NV_INGEST_DYNAMIC_BATCHING",
        description="Enable dynamic calculation of batch parameters based on file characteristics",
    )
    enable_pdf_split_processing: bool = Field(
        default=False,
        env="APP_NVINGEST_ENABLE_PDF_SPLIT_PROCESSING",
        description="Enable PDF split processing during ingestion",
    )
    pages_per_chunk: int = Field(
        default=16,
        env="APP_NVINGEST_PAGES_PER_CHUNK",
        description="Number of pages per chunk for PDF split processing",
    )
    max_memory_budget_mb: int = Field(
        default=2048,
        env="INGESTION_MAX_MEMORY_BUDGET_MB",
        description="Max memory budget (MB) for a single ingestion job; used for dynamic batch sizing",
    )
    # NRL (NeMo-Retriever Library) backend configuration — see NRL_INTEGRATION_PLAN.md §8
    backend: str = Field(
        default="nv_ingest",
        env="INGESTOR_BACKEND",
        description='Ingestion backend: "nv_ingest" (default, NV-Ingest microservice) or "nrl" (NeMo-Retriever Library in-process)',
    )
    nrl_run_mode: str = Field(
        default="batch",
        env="NRL_RUN_MODE",
        description='NRL GraphIngestor run mode: "inprocess" (default, no Ray cluster) or "batch" (Ray cluster for production throughput)',
    )


class ModelParametersConfig(_ConfigBase):
    """Model parameters configuration."""

    max_tokens: int = Field(
        default=32768,
        env="LLM_MAX_TOKENS",
        description="Maximum number of tokens to generate in response",
    )
    min_tokens: int = Field(
        default=0,
        env="LLM_MIN_TOKENS",
        description="Minimum number of tokens to generate in response",
    )
    enable_thinking: bool = Field(
        default=False,
        env="LLM_ENABLE_THINKING",
        description="Enable reasoning/thinking mode. Model emits reasoning tokens before the final answer.",
    )
    reasoning_budget: int = Field(
        default=0,
        env="LLM_REASONING_BUDGET",
        description="Token budget for reasoning (0 = no budget, model decides depth). Only used when enable_thinking is true.",
    )
    low_effort: bool = Field(
        default=False,
        env="LLM_LOW_EFFORT",
        description="Low-effort reasoning mode for faster, cheaper responses with shorter reasoning. Only used when enable_thinking is true.",
    )
    max_thinking_tokens: int = Field(
        default=0,
        env="LLM_MAX_THINKING_TOKENS",
        description="Maximum thinking tokens for reasoning models. Used directly by nemotron-nano-9b-v2; for other models acts as an alternative to reasoning_budget (0 = disabled).",
    )
    min_thinking_tokens: int = Field(
        default=0,
        env="LLM_MIN_THINKING_TOKENS",
        description="Minimum thinking tokens for reasoning models. Only used by nemotron-nano-9b-v2 (0 = disabled).",
    )
    ignore_eos: bool = Field(
        default=False,
        env="LLM_IGNORE_EOS",
        description="Ignore end-of-sequence token during generation",
    )
    temperature: float | None = Field(
        default=None,
        env="LLM_TEMPERATURE",
        description="Sampling temperature for controlling randomness. If unset, the model/provider default is used.",
    )
    top_p: float | None = Field(
        default=None,
        env="LLM_TOP_P",
        description="Nucleus sampling threshold for token selection. If unset, the model/provider default is used.",
    )

    @field_validator("temperature", mode="before")
    @classmethod
    def validate_temperature(cls, v: Any) -> float | None:
        if isinstance(v, str) and not v.strip():
            return None
        if v is None:
            return v
        v = float(v)
        if v < 0.0:
            raise ValueError("Temperature must be non-negative")
        return v

    @field_validator("top_p", mode="before")
    @classmethod
    def validate_top_p(cls, v: Any) -> float | None:
        if isinstance(v, str) and not v.strip():
            return None
        if v is None:
            return v
        v = float(v)
        if not (0.0 <= v <= 1.0):
            raise ValueError("top_p must be between 0.0 and 1.0")
        return v


class LLMConfig(_ConfigBase):
    """LLM configuration."""

    server_url: str = Field(
        default="",
        env="APP_LLM_SERVERURL",
        description="URL endpoint for the LLM inference service",
    )
    model_name: str = Field(
        default="nvidia/nemotron-3-super-120b-a12b",
        env="APP_LLM_MODELNAME",
        description="Name of the language model to use for generation",
    )
    model_engine: str = Field(
        default="nvidia-ai-endpoints",
        env="APP_LLM_MODELENGINE",
        description="Engine/provider for LLM inference (e.g., nvidia-ai-endpoints, openai)",
    )
    api_key: SecretStr | None = Field(
        default=None,
        env="APP_LLM_APIKEY",
        description="API key for LLM service (overrides global NVIDIA_API_KEY)",
    )
    parameters: ModelParametersConfig = PydanticField(
        default_factory=ModelParametersConfig, description="Model generation parameters"
    )

    @field_validator("server_url", "model_name", "model_engine", mode="before")
    @classmethod
    def normalize_string(cls, v: Any) -> Any:
        """Normalize string fields by stripping whitespace and quotes."""
        if isinstance(v, str):
            return v.strip().strip('"').strip("'")
        return v

    @field_validator("server_url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        """Ensure URL has a scheme."""
        if v and not v.startswith(("http://", "https://")):
            return f"http://{v}"
        return v

    def get_model_parameters(self) -> dict:
        """Return model parameters as dict."""
        return {
            "min_tokens": self.parameters.min_tokens,
            "ignore_eos": self.parameters.ignore_eos,
            "max_tokens": self.parameters.max_tokens,
            "enable_thinking": self.parameters.enable_thinking,
            "reasoning_budget": self.parameters.reasoning_budget,
            "low_effort": self.parameters.low_effort,
            "min_thinking_tokens": self.parameters.min_thinking_tokens,
            "max_thinking_tokens": self.parameters.max_thinking_tokens,
            "temperature": self.parameters.temperature,
            "top_p": self.parameters.top_p,
        }


class QueryRewriterConfig(_ConfigBase):
    """Query Rewriter configuration."""

    model_name: str = Field(
        default="nvidia/nemotron-3-super-120b-a12b",
        env="APP_QUERYREWRITER_MODELNAME",
        description="Model for rewriting user queries to improve retrieval",
    )
    server_url: str = Field(
        default="",
        env="APP_QUERYREWRITER_SERVERURL",
        description="URL endpoint for query rewriter service",
    )
    enable_query_rewriter: bool = Field(
        default=False,
        env="ENABLE_QUERYREWRITER",
        description="Enable automatic query rewriting before retrieval",
    )
    api_key: SecretStr | None = Field(
        default=None,
        env="APP_QUERYREWRITER_APIKEY",
        description="API key for query rewriter (overrides global NVIDIA_API_KEY)",
    )
    multiturn_retrieval_simple: bool = Field(
        default=False,
        env="MULTITURN_RETRIEVER_SIMPLE",
        description="Enable concatenating conversation history with current query for retrieval (used when query rewriter is disabled)",
    )

    @field_validator("server_url", mode="before")
    @classmethod
    def normalize_url(cls, v: Any) -> Any:
        """Normalize URL fields by stripping whitespace/quotes and adding scheme."""
        if isinstance(v, str):
            v = v.strip().strip('"').strip("'")
            if v and not v.startswith(("http://", "https://")):
                return f"http://{v}"
        return v


class FilterExpressionGeneratorConfig(_ConfigBase):
    """Filter Expression Generator configuration."""

    model_name: str = Field(
        default="nvidia/nemotron-3-super-120b-a12b",
        env="APP_FILTEREXPRESSIONGENERATOR_MODELNAME",
        description="Model for generating metadata filter expressions from queries",
    )
    server_url: str = Field(
        default="",
        env="APP_FILTEREXPRESSIONGENERATOR_SERVERURL",
        description="URL endpoint for filter expression generator service",
    )
    enable_filter_generator: bool = Field(
        default=False,
        env="ENABLE_FILTER_GENERATOR",
        description="Enable automatic filter expression generation from natural language",
    )
    temperature: float = Field(
        default=0.0,
        env="APP_FILTEREXPRESSIONGENERATOR_TEMPERATURE",
        description="Sampling temperature for filter generation",
    )
    top_p: float = Field(
        default=1.0,
        env="APP_FILTEREXPRESSIONGENERATOR_TOPP",
        description="Nucleus sampling threshold for filter generation",
    )
    max_tokens: int = Field(
        default=32768,
        env="APP_FILTEREXPRESSIONGENERATOR_MAXTOKENS",
        description="Maximum tokens for filter expression generation",
    )
    api_key: SecretStr | None = Field(
        default=None,
        env="APP_FILTEREXPRESSIONGENERATOR_APIKEY",
        description="API key for filter generator (overrides global NVIDIA_API_KEY)",
    )

    @field_validator("server_url", mode="before")
    @classmethod
    def normalize_url(cls, v: Any) -> Any:
        """Normalize URL fields by stripping whitespace/quotes and adding scheme."""
        if isinstance(v, str):
            v = v.strip().strip('"').strip("'")
            if v and not v.startswith(("http://", "https://")):
                return f"http://{v}"
        return v


class TextSplitterConfig(_ConfigBase):
    """Text Splitter configuration."""

    model_name: str = Field(
        default="Snowflake/snowflake-arctic-embed-l",
        env="APP_TEXTSPLITTER_MODELNAME",
        description="Tokenizer model for text splitting",
    )
    chunk_size: int = Field(
        default=510,
        env="APP_TEXTSPLITTER_CHUNKSIZE",
        description="Target size for text chunks in tokens",
    )
    chunk_overlap: int = Field(
        default=200,
        env="APP_TEXTSPLITTER_CHUNKOVERLAP",
        description="Number of overlapping tokens between consecutive chunks",
    )

    @model_validator(mode="after")
    def validate_chunk_settings(self) -> "TextSplitterConfig":
        if self.chunk_overlap > self.chunk_size:
            raise ValueError(
                f"chunk_overlap ({self.chunk_overlap}) must be less than chunk_size ({self.chunk_size})"
            )
        return self


class EmbeddingConfig(_ConfigBase):
    """Embedding configuration."""

    model_name: str = Field(
        default="nvidia/llama-nemotron-embed-vl-1b-v2",
        env="APP_EMBEDDINGS_MODELNAME",
        description="Model for generating embeddings",
    )
    model_engine: str = Field(
        default="nvidia-ai-endpoints",
        env="APP_EMBEDDINGS_MODELENGINE",
        description="Engine/provider for embedding generation",
    )
    dimensions: int = Field(
        default=2048,
        env="APP_EMBEDDINGS_DIMENSIONS",
        description="Dimensionality of the embedding vectors",
    )
    server_url: str = Field(
        default="",
        env="APP_EMBEDDINGS_SERVERURL",
        description="URL endpoint for embedding service",
    )
    api_key: SecretStr | None = Field(
        default=None,
        env="APP_EMBEDDINGS_APIKEY",
        description="API key for embedding service (overrides global NVIDIA_API_KEY)",
    )

    @field_validator("server_url", mode="before")
    @classmethod
    def normalize_url(cls, v: Any) -> Any:
        """Normalize URL fields by stripping whitespace/quotes and adding scheme."""
        if isinstance(v, str):
            v = v.strip().strip('"').strip("'")
            if v and not v.startswith(("http://", "https://")):
                return f"http://{v}"
        return v


class RankingConfig(_ConfigBase):
    """Ranking configuration."""

    model_name: str = Field(
        default="nvidia/llama-nemotron-rerank-1b-v2",
        env="APP_RANKING_MODELNAME",
        description="Model for reranking retrieved documents",
    )
    model_engine: str = Field(
        default="nvidia-ai-endpoints",
        env="APP_RANKING_MODELENGINE",
        description="Engine/provider for reranking service",
    )
    server_url: str = Field(
        default="",
        env="APP_RANKING_SERVERURL",
        description="URL endpoint for reranking service",
    )
    enable_reranker: bool = Field(
        default=True,
        env="ENABLE_RERANKER",
        description="Enable reranking of retrieved documents before generation",
    )
    enable_vlm_image_input: bool = Field(
        default=False,
        env="ENABLE_VLM_RERANKER_IMAGE_INPUT",
        description="When True, include images from retrieved citations in VLM reranker passages",
    )
    api_key: SecretStr | None = Field(
        default=None,
        env="APP_RANKING_APIKEY",
        description="API key for ranking service (overrides global NVIDIA_API_KEY)",
    )

    @field_validator("server_url", mode="before")
    @classmethod
    def normalize_url(cls, v: Any) -> Any:
        """Normalize URL fields by stripping whitespace/quotes and adding scheme."""
        if isinstance(v, str):
            v = v.strip().strip('"').strip("'")
            if v and not v.startswith(("http://", "https://")):
                return f"http://{v}"
        return v


class RetrieverConfig(_ConfigBase):
    """Retriever configuration."""

    top_k: int = Field(
        default=10,
        env="APP_RETRIEVER_TOPK",
        description="Number of top documents to return after retrieval and reranking",
    )
    vdb_top_k: int = Field(
        default=100,
        env="VECTOR_DB_TOPK",
        description="Number of documents to retrieve from vector database before reranking",
    )
    score_threshold: float = Field(
        default=0.25,
        env="APP_RETRIEVER_SCORETHRESHOLD",
        description="Minimum similarity score threshold for retrieved documents",
    )
    nr_url: str = Field(
        default="http://retrieval-ms:8000",
        env="APP_RETRIEVER_NRURL",
        description="URL for NVIDIA Retrieval microservice",
    )
    nr_pipeline: str = Field(
        default="ranked_hybrid",
        env="APP_RETRIEVER_NRPIPELINE",
        description="Retrieval pipeline to use (e.g., ranked_hybrid, dense, sparse)",
    )
    fetch_full_page_context: bool = Field(
        default=False,
        env="APP_FETCH_FULL_PAGE_CONTEXT",
        description="Fetch ALL chunks for retrieved pages and organize context by page. "
        "When True, enables page-based grouping for LLM/VLM.",
    )
    fetch_neighboring_pages: int = Field(
        default=0,
        env="APP_FETCH_NEIGHBORING_PAGES",
        description="N pages before/after each retrieved page (0=disabled, 1=+/-1 page). "
        "Requires fetch_full_page_context=True.",
    )

    @field_validator("nr_url", mode="before")
    @classmethod
    def normalize_url(cls, v: Any) -> Any:
        """Normalize URL fields by stripping whitespace/quotes and adding scheme."""
        if isinstance(v, str):
            v = v.strip().strip('"').strip("'")
            if v and not v.startswith(("http://", "https://")):
                return f"http://{v}"
        return v

    @field_validator("vdb_top_k")
    @classmethod
    def validate_vdb_top_k(cls, v: int) -> int:
        if not isinstance(v, int) or isinstance(v, bool):
            raise TypeError(f"vdb_top_k must be an integer, got {type(v).__name__}")
        if v <= 0:
            raise ValueError(
                f"vdb_top_k must be greater than 0, got {v}. "
                "Please provide a positive integer for the number of documents to retrieve from the vector database."
            )
        if v > 400:
            logger.warning(
                "VECTOR_DB_TOPK=%s is outside the request limit of 1..400. "
                "The server will start so the value can be corrected from the UI "
                "or environment, but /v1/generate and /v1/search requests using "
                "this value will be rejected.",
                v,
            )
        return v

    @field_validator("fetch_neighboring_pages")
    @classmethod
    def validate_fetch_neighboring_pages(cls, v: int) -> int:
        if not isinstance(v, int) or isinstance(v, bool):
            raise TypeError(
                f"fetch_neighboring_pages must be an integer, got {type(v).__name__}"
            )
        if v < 0:
            raise ValueError(f"fetch_neighboring_pages must be >= 0, got {v}")
        if v > 10:
            raise ValueError(f"fetch_neighboring_pages must be <= 10, got {v}")
        return v

    @model_validator(mode="after")
    def validate_reranker_top_k(self) -> "RetrieverConfig":
        if self.vdb_top_k is not None and self.top_k > self.vdb_top_k:
            raise ValueError(
                f"reranker_top_k ({self.top_k}) must be less than or equal to vdb_top_k ({self.vdb_top_k}). "
                "Please check your settings and try again."
            )
        return self

    @model_validator(mode="after")
    def validate_page_context_options(self) -> "RetrieverConfig":
        if self.fetch_neighboring_pages > 0 and not self.fetch_full_page_context:
            raise ValueError(
                "fetch_full_page_context must be True when fetch_neighboring_pages > 0."
            )
        return self


class TracingConfig(_ConfigBase):
    """Tracing configuration."""

    enabled: bool = Field(
        default=False,
        env="APP_TRACING_ENABLED",
        description="Enable distributed tracing and metrics collection",
    )
    otlp_http_endpoint: str = Field(
        default="",
        env="APP_TRACING_OTLPHTTPENDPOINT",
        description="OpenTelemetry HTTP endpoint for traces",
    )
    otlp_grpc_endpoint: str = Field(
        default="",
        env="APP_TRACING_OTLPGRPCENDPOINT",
        description="OpenTelemetry gRPC endpoint for traces",
    )
    prometheus_multiproc_dir: str = Field(
        default="/tmp/prom_data",
        env="PROMETHEUS_MULTIPROC_DIR",
        description="Directory for Prometheus multiprocess metrics",
    )

    @field_validator("otlp_http_endpoint", mode="before")
    @classmethod
    def normalize_url(cls, v: Any) -> Any:
        """Normalize URL fields by stripping whitespace/quotes and adding scheme."""
        if isinstance(v, str):
            v = v.strip().strip('"').strip("'")
            if v and not v.startswith(("http://", "https://")):
                return f"http://{v}"
        return v


class VLMConfig(_ConfigBase):
    """VLM configuration."""

    server_url: str = Field(
        default="http://localhost:8000/v1",
        env="APP_VLM_SERVERURL",
        description="URL endpoint for Vision-Language Model service",
    )
    model_name: str = Field(
        default="nvidia/nemotron-3-nano-omni-30b-a3b-reasoning",
        env="APP_VLM_MODELNAME",
        description="Vision-Language Model for processing images and text",
    )
    temperature: float = Field(
        default=0.7,
        env="APP_VLM_TEMPERATURE",
        description="Sampling temperature for VLM generation",
    )
    top_p: float = Field(
        default=1.0,
        env="APP_VLM_TOP_P",
        description="Top-p sampling mass for VLM generation",
    )
    max_tokens: int = Field(
        default=4096,
        env="APP_VLM_MAX_TOKENS",
        description="Maximum number of tokens to generate in any given VLM call",
    )
    max_total_images: int = Field(
        default=5,
        env="APP_VLM_MAX_TOTAL_IMAGES",
        description="Maximum total images sent to VLM per request (query + context)",
    )
    enable_thinking: bool = Field(
        default=True,
        env="APP_VLM_ENABLE_THINKING",
        description=(
            "Enable reasoning mode for the VLM (nvidia/nemotron-3-nano-omni-30b-a3b-reasoning). "
            "When True the model separates chain-of-thought into the 'reasoning' field and the "
            "final answer into 'content'. Set False to skip reasoning entirely."
        ),
    )
    thinking_token_budget: int = Field(
        default=0,
        env="APP_VLM_THINKING_TOKEN_BUDGET",
        description=(
            "Maximum tokens the VLM may use for reasoning (0 = no budget cap). "
            "Only applied when enable_thinking is True."
        ),
    )
    filter_think_tokens: bool = Field(
        default=True,
        env="VLM_FILTER_THINK_TOKENS",
        description=(
            "Controls legacy VLM reasoning filtering behavior. Reasoning tokens "
            "are filtered out of the user-facing content stream and surfaced in "
            "delta.reasoning_content when the model emits them."
        ),
    )
    api_key: SecretStr | None = Field(
        default=None,
        env="APP_VLM_APIKEY",
        description="API key for VLM service (overrides global NVIDIA_API_KEY)",
    )

    @field_validator("server_url", mode="before")
    @classmethod
    def normalize_url(cls, v: Any) -> Any:
        """Normalize URL fields by stripping whitespace/quotes and adding scheme."""
        if isinstance(v, str):
            v = v.strip().strip('"').strip("'")
            if v and not v.startswith(("http://", "https://")):
                return f"http://{v}"
        return v


class ObjectStoreConfig(_ConfigBase):
    """Object-store configuration for S3-compatible backends."""

    backend: str = Field(
        default="s3",
        env="OBJECTSTORE_BACKEND",
        description='Object-store backend: "s3" or "filesystem"',
    )
    endpoint: str = Field(
        default="localhost:9010",
        env="OBJECTSTORE_ENDPOINT",
        description="Object-store endpoint in host:port form",
    )
    nv_ingest_endpoint: str | None = Field(
        default=None,
        env="NVINGEST_OBJECTSTORE_ENDPOINT",
        description=(
            "Object-store endpoint reachable from the NV-Ingest runtime. "
            "Defaults to endpoint when unset."
        ),
    )
    access_key: SecretStr = Field(
        default=SecretStr("seaweedfsadmin"),
        env="OBJECTSTORE_ACCESSKEY",
        description="Object-store access key for authentication",
    )
    secret_key: SecretStr = Field(
        default=SecretStr("seaweedfsadmin"),
        env="OBJECTSTORE_SECRETKEY",
        description="Object-store secret key for authentication",
    )
    secure: bool = Field(
        default=False,
        description="Whether to use TLS when connecting to the object store",
    )
    nv_ingest_secure: bool | None = Field(
        default=None,
        description=(
            "Whether the NV-Ingest runtime should use TLS for object-store access. "
            "Defaults to secure when unset."
        ),
    )
    local_path: str = Field(
        default="/tmp/nvidia-rag-object-store",
        env="OBJECTSTORE_LOCAL_PATH",
        description="Root path for the filesystem-backed object store",
    )

    @field_validator("backend", mode="before")
    @classmethod
    def normalize_backend(cls, value: Any) -> Any:
        if isinstance(value, str):
            normalized = value.strip().strip('"').strip("'").lower()
            if normalized not in {"s3", "filesystem"}:
                raise ValueError(
                    f"Unsupported object-store backend: {value!r}. Supported backends: s3, filesystem"
                )
            return normalized
        return value

    @field_validator("local_path", mode="before")
    @classmethod
    def normalize_local_path(cls, value: Any) -> Any:
        if isinstance(value, str):
            return value.strip().strip('"').strip("'")
        return value

    @classmethod
    def _normalize_endpoint(cls, value: str) -> tuple[str, bool | None]:
        normalized = value.strip().strip('"').strip("'")
        if "://" not in normalized:
            return normalized, None

        parsed = urlparse(normalized)
        return parsed.netloc or parsed.path, parsed.scheme == "https"

    @model_validator(mode="before")
    @classmethod
    def normalize_object_store_values(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data

        normalized = dict(data)
        endpoint = normalized.get("endpoint")
        if isinstance(endpoint, str) and endpoint:
            normalized_endpoint, secure = cls._normalize_endpoint(endpoint)
            normalized["endpoint"] = normalized_endpoint
            if secure is not None:
                normalized.setdefault("secure", secure)

        nv_ingest_endpoint = normalized.get("nv_ingest_endpoint")
        if isinstance(nv_ingest_endpoint, str) and nv_ingest_endpoint:
            normalized_endpoint, secure = cls._normalize_endpoint(nv_ingest_endpoint)
            normalized["nv_ingest_endpoint"] = normalized_endpoint
            if secure is not None:
                normalized.setdefault("nv_ingest_secure", secure)

        return normalized

    @staticmethod
    def _endpoint_url(endpoint: str, secure: bool) -> str:
        scheme = "https" if secure else "http"
        return f"{scheme}://{endpoint}"

    @property
    def endpoint_url(self) -> str:
        return self._endpoint_url(self.endpoint, self.secure)

    @property
    def nv_ingest_endpoint_url(self) -> str:
        endpoint = self.nv_ingest_endpoint or self.endpoint
        secure = self.secure if self.nv_ingest_secure is None else self.nv_ingest_secure
        return self._endpoint_url(endpoint, secure)

    @property
    def storage_root(self) -> Path:
        return Path(self.local_path).expanduser().resolve()


class SummarizerConfig(_ConfigBase):
    """Summarizer configuration."""

    model_name: str = Field(
        default="nvidia/nemotron-3-super-120b-a12b",
        env="SUMMARY_LLM",
        description="Model for generating document summaries",
    )
    server_url: str = Field(
        default="",
        env="SUMMARY_LLM_SERVERURL",
        description="URL endpoint for summarization service",
    )
    max_chunk_length: int = Field(
        default=9000,
        env="SUMMARY_LLM_MAX_CHUNK_LENGTH",
        description="Maximum chunk size in tokens for the summarizer model",
    )
    chunk_overlap: int = Field(
        default=400,
        env="SUMMARY_CHUNK_OVERLAP",
        description="Overlap between chunks for iterative summarization (in tokens)",
    )
    temperature: float = Field(
        default=0.0,
        env="SUMMARY_LLM_TEMPERATURE",
        description="Sampling temperature for summary generation",
    )
    top_p: float = Field(
        default=1.0,
        env="SUMMARY_LLM_TOP_P",
        description="Nucleus sampling threshold for summary generation",
    )
    max_parallelization: int = Field(
        default=20,
        env="SUMMARY_MAX_PARALLELIZATION",
        description="Maximum concurrent summaries across entire system (coordinated via Redis)",
    )
    api_key: SecretStr | None = Field(
        default=None,
        env="SUMMARY_LLM_APIKEY",
        description="API key for summarization service (overrides global NVIDIA_API_KEY)",
    )

    @field_validator("server_url", mode="before")
    @classmethod
    def normalize_url(cls, v: Any) -> Any:
        """Normalize URL fields by stripping whitespace/quotes and adding scheme."""
        if isinstance(v, str):
            v = v.strip().strip('"').strip("'")
            if v and not v.startswith(("http://", "https://")):
                return f"http://{v}"
        return v


class MetadataConfig(_ConfigBase):
    """Metadata configuration."""

    max_array_length: int = Field(
        default=1000,
        env="APP_METADATA_MAXARRAYLENGTH",
        description="Maximum length for array-type metadata fields",
    )
    max_string_length: int = Field(
        default=65535,
        env="APP_METADATA_MAXSTRINGLENGTH",
        description="Maximum length for string-type metadata fields",
    )
    allow_partial_filtering: bool = Field(
        default=False,
        env="APP_METADATA_ALLOWPARTIALFILTERING",
        description="Allow partial matches in metadata filtering",
    )


class QueryDecompositionConfig(_ConfigBase):
    """Query Decomposition configuration."""

    enable_query_decomposition: bool = Field(
        default=False,
        env="ENABLE_QUERY_DECOMPOSITION",
        description="Enable breaking down complex queries into sub-queries",
    )
    recursion_depth: int = Field(
        default=3,
        env="MAX_RECURSION_DEPTH",
        description="Maximum depth for recursive query decomposition",
    )


class ReflectionConfig(_ConfigBase):
    """Reflection configuration for context relevance and response groundedness."""

    enable_reflection: bool = Field(
        default=False,
        env="ENABLE_REFLECTION",
        description="Enable self-reflection to improve answer quality",
    )
    max_loops: int = Field(
        default=3,
        env="MAX_REFLECTION_LOOP",
        description="Maximum number of reflection iterations",
    )
    model_name: str = Field(
        default="nvidia/nemotron-3-super-120b-a12b",
        env="REFLECTION_LLM",
        description="Model for reflection and quality assessment",
    )
    server_url: str = Field(
        default="",
        env="REFLECTION_LLM_SERVERURL",
        description="URL endpoint for reflection service",
    )
    context_relevance_threshold: int = Field(
        default=1,
        env="CONTEXT_RELEVANCE_THRESHOLD",
        description="Minimum relevance score for context to be considered useful",
    )
    response_groundedness_threshold: int = Field(
        default=1,
        env="RESPONSE_GROUNDEDNESS_THRESHOLD",
        description="Minimum groundedness score for response to be considered factual",
    )
    api_key: SecretStr | None = Field(
        default=None,
        env="REFLECTION_LLM_APIKEY",
        description="API key for reflection service (overrides global NVIDIA_API_KEY)",
    )

    @field_validator("server_url", mode="before")
    @classmethod
    def normalize_url(cls, v: Any) -> Any:
        """Normalize URL fields by stripping whitespace/quotes and adding scheme."""
        if isinstance(v, str):
            v = v.strip().strip('"').strip("'")
            if v and not v.startswith(("http://", "https://")):
                return f"http://{v}"
        return v


# Agentic RAG config classes live in a dedicated module to avoid bloating
# this file.  Import must happen after _ConfigBase and Field are defined above
# (Python partial-module resolution handles the deliberate circular reference).
from nvidia_rag.utils.agentic_rag_config import AgenticRAGConfig  # noqa: E402


class NvidiaRAGConfig(_ConfigBase):
    """Main NVIDIA RAG configuration.

    Priority order (highest to lowest):
    1. Config file values (YAML/JSON)
    2. Environment variables
    3. Default values
    """

    model_config = ConfigDict(extra="allow", protected_namespaces=())

    vector_store: VectorStoreConfig = PydanticField(default_factory=VectorStoreConfig)
    llm: LLMConfig = PydanticField(default_factory=LLMConfig)
    query_rewriter: QueryRewriterConfig = PydanticField(
        default_factory=QueryRewriterConfig
    )
    filter_expression_generator: FilterExpressionGeneratorConfig = PydanticField(
        default_factory=FilterExpressionGeneratorConfig
    )
    text_splitter: TextSplitterConfig = PydanticField(
        default_factory=TextSplitterConfig
    )
    embeddings: EmbeddingConfig = PydanticField(default_factory=EmbeddingConfig)
    ranking: RankingConfig = PydanticField(default_factory=RankingConfig)
    retriever: RetrieverConfig = PydanticField(default_factory=RetrieverConfig)
    nv_ingest: NvIngestConfig = PydanticField(default_factory=NvIngestConfig)
    tracing: TracingConfig = PydanticField(default_factory=TracingConfig)
    vlm: VLMConfig = PydanticField(default_factory=VLMConfig)
    object_store: ObjectStoreConfig = PydanticField(default_factory=ObjectStoreConfig)
    summarizer: SummarizerConfig = PydanticField(default_factory=SummarizerConfig)
    metadata: MetadataConfig = PydanticField(default_factory=MetadataConfig)
    query_decomposition: QueryDecompositionConfig = PydanticField(
        default_factory=QueryDecompositionConfig
    )
    reflection: ReflectionConfig = PydanticField(default_factory=ReflectionConfig)
    agentic_rag: AgenticRAGConfig = PydanticField(default_factory=AgenticRAGConfig)

    # Top-level flags
    enable_agentic_rag: bool = Field(
        default=False,
        env="ENABLE_AGENTIC_RAG",
        description=(
            "Enable the agentic RAG pipeline for knowledge-base queries. "
            "When True, requests with use_knowledge_base=True are routed through "
            "the LangGraph plan-and-execute agent instead of the standard RAG chain. "
            "Can be overridden per-request via the agentic parameter in the request body."
        ),
    )
    enable_guardrails: bool = Field(
        default=False,
        env="ENABLE_GUARDRAILS",
        description="Enable safety guardrails for input/output filtering",
    )
    enable_citations: bool = Field(
        default=True,
        env="ENABLE_CITATIONS",
        description="Include source citations in generated responses",
    )
    enable_vlm_inference: bool = Field(
        default=False,
        env="ENABLE_VLM_INFERENCE",
        description="Enable Vision-Language Model for multimodal queries",
    )
    vlm_to_llm_fallback: bool = Field(
        default=True,
        env="VLM_TO_LLM_FALLBACK",
        description=(
            "When true, if ENABLE_VLM_INFERENCE is on but no images are present in query, "
            "messages, or context, the pipeline will fall back to the standard LLM RAG flow. "
            "When false, VLM will be invoked even for text-only queries."
        ),
    )
    default_confidence_threshold: float = Field(
        default=0.0,
        env="RERANKER_SCORE_THRESHOLD",
        description="Default confidence threshold for reranker chunk filtering (0.0-1.0).",
    )
    temp_dir: str = Field(
        default="./tmp-data",
        env="TEMP_DIR",
        description="Temporary directory for file processing and storage",
    )

    @field_validator("default_confidence_threshold")
    @classmethod
    def validate_confidence_threshold(cls, v: float) -> float:
        if not (0.0 <= v <= 1.0):
            raise ValueError(
                f"confidence_threshold must be between 0.0 and 1.0, got {v}. "
                "The confidence threshold represents the minimum relevance score required for documents to be included."
            )
        return v

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "NvidiaRAGConfig":
        """Create config from dictionary.

        Priority: dict values > env vars > defaults

        Args:
            data: Configuration dictionary

        Returns:
            NvidiaRAGConfig instance
        """
        # Direct instantiation - constructor args have priority over env vars in pydantic-settings
        return cls(**data)

    @classmethod
    def from_yaml(cls, filepath: str) -> "NvidiaRAGConfig":
        """Create config from YAML file.

        Priority: YAML values > env vars > defaults

        Args:
            filepath: Path to YAML file

        Returns:
            NvidiaRAGConfig instance
        """
        path = Path(filepath)
        if not path.exists():
            return cls()

        with open(path) as f:
            data = yaml.safe_load(f) or {}

        return cls.from_dict(data)

    @classmethod
    def from_json(cls, filepath: str) -> "NvidiaRAGConfig":
        """Create config from JSON file.

        Priority: JSON values > env vars > defaults

        Args:
            filepath: Path to JSON file

        Returns:
            NvidiaRAGConfig instance
        """
        path = Path(filepath)
        if not path.exists():
            return cls()

        with open(path) as f:
            data = json.load(f)

        return cls.from_dict(data)

    def __str__(self) -> str:
        """Return formatted config as YAML-like string for easy reading.

        Uses mode='json' to properly mask SecretStr fields (api_key, password, etc.)
        as '**********' instead of exposing actual values.
        """
        return yaml.dump(
            self.model_dump(mode="json"),
            default_flow_style=False,
            sort_keys=False,
            indent=2,
            width=120,
            allow_unicode=True,
        )
